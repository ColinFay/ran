library(testthat)
library(ariel)

test_check("ariel")
