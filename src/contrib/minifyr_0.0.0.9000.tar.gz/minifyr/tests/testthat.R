library(testthat)
library(minifyr)

test_check("minifyr")
