library(testthat)
library(tweetthat)

test_check("tweetthat")
