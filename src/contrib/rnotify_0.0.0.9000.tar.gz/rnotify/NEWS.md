# rnotify 0.0.0.9000

* pushed first version
* Added a `NEWS.md` file to track changes to the package.
