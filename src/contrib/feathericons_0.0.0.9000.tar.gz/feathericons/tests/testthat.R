library(testthat)
library(feathericons)

test_check("feathericons")
