library(testthat)
library(tidystringdist)

test_check("tidystringdist")
