library(testthat)
library(attempt)

test_check("attempt")
