#' lexiquer
#'
#' Access the lexique 3.81 database
#'
#' @importFrom dplyr select rename left_join
#' @importFrom rlang enexpr
#'
#' @source http://www.lexique.org/
#'
#' @name lexiquer

NULL
