# lexiquer 0.0.0.9000

2017-11

* bind_lemme

2017-10

* first commit
* Added a `NEWS.md` file to track changes to the package.



