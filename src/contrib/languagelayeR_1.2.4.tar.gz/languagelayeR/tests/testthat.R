library(testthat)
library(languagelayeR)

test_check("languagelayeR")
