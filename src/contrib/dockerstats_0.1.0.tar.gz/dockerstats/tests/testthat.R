library(testthat)
library(dockerstats)

test_check("dockerstats")
