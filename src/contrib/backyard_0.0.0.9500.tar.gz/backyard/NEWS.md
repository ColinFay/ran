# backyard 0.0.0.9000

## Septembre 2018 

* run_app is now run_book (prepare for future generalisation of the concept)
* New: app is now launched with a safe mode (copy the dir to dir_copy)
* Default launching is now on `.`
* First dev release in Open Source
* Added a `NEWS.md` file to track changes to the package.
