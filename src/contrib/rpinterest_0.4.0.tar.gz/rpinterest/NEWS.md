# rpinterest 0.4.0

## Changes

* New Pinterest authentification is now supported

## Breaking changes 

* Function names changed to snake_case