library(testthat)
library(lexiquer)

test_check("lexiquer")
