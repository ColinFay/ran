library(testthat)
library(odds)

test_check("odds")
