library(testthat)
library(rnotify)

test_check("rnotify")
