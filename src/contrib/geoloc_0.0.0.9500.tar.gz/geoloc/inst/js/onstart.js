$(document).ready( function () {
  getLocation();
});
