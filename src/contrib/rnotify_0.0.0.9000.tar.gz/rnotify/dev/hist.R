usethis::use_build_ignore("dev/")
usethis::use_build_ignore("rnotify.gif")

colin::init_docs()

colin::new_r_file("wrap")

usethis::use_package("processx")
