library(testthat)
library(handydandy)

test_check("handydandy")
