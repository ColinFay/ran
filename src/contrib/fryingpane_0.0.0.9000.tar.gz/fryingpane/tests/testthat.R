library(testthat)
library(fryingpane)

test_check("fryingpane")
