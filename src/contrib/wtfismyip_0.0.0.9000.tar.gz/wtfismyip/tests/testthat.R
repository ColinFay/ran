library(testthat)
library(wtfismyip)

test_check("wtfismyip")
