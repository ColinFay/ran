#' List of feather icons
#'
#' Simply beautiful open source icons
#'
#' @format A vector of 266 icons

#' @source \url{https://feathericons.com/}
"icons_list"
