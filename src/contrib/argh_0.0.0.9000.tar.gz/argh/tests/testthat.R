library(testthat)
library(argh)

test_check("argh")
