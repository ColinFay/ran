#' dockerstats package
#'
#' A wrapper around the `dockerstats` command to analyse doker data from R.
#'
#' @name dockerstats-package
#' @aliases dockerstats-package
#' @docType package
#' @author colin <contact@@colinfay.me>
NULL
