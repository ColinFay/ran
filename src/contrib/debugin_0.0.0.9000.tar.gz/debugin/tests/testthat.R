library(testthat)
library(debugin)

test_check("debugin")
